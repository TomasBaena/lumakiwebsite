function openMail() {
  window.location.href = "mailto:tomasbaena@lumaki.co";
}

$(document).ready(function() {
});
      

